# VideoCodingP1
 To be able to compile this document you have to have ffmpeg and an image may want to compress, turn to black and white and compress on the same directory as the script
 Dídac Freire
 218254
https://github.com/FreireDidac/VideoCodingP1
